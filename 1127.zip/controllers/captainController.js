const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Login = require('../models/Login'); // 登入模型
const Attendance = require('../models/Attendance'); // 出勤記錄模型
const Worker = require('../models/Worker'); // 船員模型

const SECRET_KEY = 'secret_key';
// 船長登入
const captainLogin = async (req, res) => {
  const { username, password } = req.body;
  try {
    // 查詢用戶是否存在（根據 username 和 role）
    const captain = await Login.findOne({ where: { username, role: 'captain' } });

    if (!captain) {
      // 如果查無此帳號
      return res.status(401).json({ error: '登入失敗，請檢查帳號是否正確' });
    }

    // 使用 bcrypt 比對密碼
    const isPasswordValid = await bcrypt.compare(password, captain.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: '登入失敗，密碼錯誤' });
    }
    // 密碼正確，生成 Token
    const token = jwt.sign(
      { username: captain.username, role: captain.role, id: captain.id }, // Payload
      SECRET_KEY,
      { expiresIn: '1h' } // Token 有效期
    );

    // 返回 Token 給前端
    res.status(200).json({ message: '登入成功', token });
    // res.status(200).json({ message: '登入成功', captain });
  } catch (error) {
    console.error('船長登入錯誤:', error);
    res.status(500).json({ error: '伺服器錯誤，無法完成登入' });
  }
};

// 新增工作記錄
const addWorkLog = async (req, res) => {
  const { workerId, date, status, timeStart, timeEnd, comments } = req.body;
  try {
    if (!worker_id || !date || !status || !timeStart || !timeEnd) {
      return res.status(400).json({ error: '缺少必要參數' });
    }
    workerId = worker_id
    // 確認時間合理性
    if (timeEnd <= timeStart) {
      return res.status(400).json({ error: '結束時間必須晚於開始時間' });
    }
    const duration = timeEnd - timeStart;

    // 確認船員是否存在
    const worker = await Worker.findByPk(workerId);
    if (!worker) {
      return res.status(404).json({ error: '找不到對應的船員' });
    }

    // 計算當天累計工作時長
    const workLogsForDay = await Attendance.findAll({
      where: { worker_id: workerId, date, status: 'working' }
    });

    const totalWorkHours = workLogsForDay.reduce((sum, log) => sum + log.duration, 0) + duration;

    if (totalWorkHours > 14) {
      return res.status(400).json({ warning: '累計工作時長超過 14 小時', totalWorkHours });
    }

    // 新增出勤記錄
    const workLog = await Attendance.create({
      Worker_id: workerId,
      date,
      status,
      timeStart,
      timeEnd,
      duration,
      comments,
    });

    res.status(201).json({ message: '工作記錄新增成功', workLog });
  } catch (error) {
    res.status(500).json({ error: '伺服器錯誤，無法新增工作記錄' });
  }
};

// 查看已登記的工作記錄
const viewWorkLogs = async (req, res) => {
  const { workerId } = req.params;
  try {
    if (!workerId) {
      return res.status(400).json({ error: '請提供 workerId' });
    }
    // 查詢該船員的所有出勤記錄
    const workLogs = await Attendance.findAll({
      where: { Worker_id: workerId },
      order: [['date', 'ASC'], ['timeStart', 'ASC']],
    });

    if (workLogs.length === 0) {
      return res.status(404).json({ error: '未找到該船員的任何工作記錄' });
    }

    res.status(200).json({ workLogs });
  } catch (error) {
    res.status(500).json({ error: '伺服器錯誤，無法檢視工作記錄' });
  }
};

module.exports = {captainLogin, addWorkLog, viewWorkLogs,};
