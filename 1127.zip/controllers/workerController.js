const bcrypt = require('bcrypt');
const Worker = require('../models/Worker');
const Login = require('../models/Login');

// 新增船員
const addWorker = async (req, res) => {
  const { worker_id, given_name, family_name, age, country, passport_number, job_title, username, password } = req.body;

  try {
    // 創建 Worker 資料
    const newWorker = await Worker.create({ worker_id, given_name, family_name, age, country, passport_number, job_title });
    
    // 檢查密碼是否存在且有效
    if (!password || password.trim() === '') {
      return res.status(400).json({ error: '密碼不可為空' });
    }

    // 自動生成 username (規則: given_name.family_name)
    const username = `${given_name.toLowerCase()}.${family_name.toLowerCase()}`;
    
    // 加密密碼
    const hashedPassword = await bcrypt.hash(password, 10);

    // 創建對應的 Login 資料
    await Login.create({ username, password: hashedPassword, role: 'worker', worker_id: newWorker.id });

    res.status(201).json({ message: '新增員工成功，並建立登入帳號', worker: newWorker, username });
  } catch (error) {
    console.error('新增員工失敗:', error.errors || error.message);
    res.status(500).json({ error: '新增員工失敗，請檢查輸入資料是否完整或有衝突' });
  }
};

// 查詢單一船員
const getWorker = async (req, res) => {
  const { id } = req.params;
  try {
    const worker = await Worker.findByPk(id);
    if (!worker) return res.status(404).json({ error: '找不到該船員' });
    res.json(worker);
  } catch (error) {
    console.error('無法查詢船員資料', error.errors || error.message); // 顯示具體錯誤
    res.status(500).json({ error: '無法查詢船員資料' });
  }
};

const getAllWorker = async (req, res) => {
  try {
    const workers = await Worker.findAll(); // 查詢所有船員
    res.json(workers);
  } catch (error) {
    console.error('無法查詢船員資料', error.errors || error.message); // 顯示具體錯誤
    res.status(500).json({ error: '無法查詢船員資料' });
  }
};

module.exports = { addWorker, getWorker, getAllWorker };