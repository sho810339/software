const sequelize = require('./config/database');
const Worker = require('./models/Worker');
const Login = require('./models/Login');
const Attendance = require('./models/Attendance');

(async () => {
  try {
    // 強制刪除並重建資料表
    await sequelize.sync({ force: true }); // 使用 { alter: true } 僅更新表結構，不刪除資料
    console.log('資料表強制同步成功');
  } catch (error) {
    console.error('資料表強制同步失敗:', error);
  } finally {
    await sequelize.close();
  }
})();
