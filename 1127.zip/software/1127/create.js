// 創建表

const sequelize = require('./config/database');
const Attendance = require('./models/Attendance');
const Login = require('./models/Login');

// 同步資料表
sequelize.sync({ force: true }) // 設置為 true 會刪除並重新創建表，僅在需要重建時使用
  .then(() => console.log('資料表同步成功'))
  .catch(err => console.error('資料表同步失敗:', err));