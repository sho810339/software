const Login = require('../models/Login');
const bcrypt = require('bcrypt');
const Attendance = require('../models/Attendance');

// 登入功能
const login = async (req, res) => {
  const { username, password } = req.body;
  try {
    // 查詢帳號
    const user = await Login.findOne({ where: { username, role: 'worker' } });
    
    if (!user) return res.status(401).json({ error: '登入失敗，帳號不存在或無權限' });
    
    // 比對密碼
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) return res.status(401).json({ error: '登入失敗，密碼錯誤' });

    res.json({ message: '登入成功', user });
  } catch (error) {
    console.log('使用者輸入的資料:', username, password);
    console.log('查詢的用戶:', user);
    console.log('密碼是否匹配:', isPasswordValid);
    console.error('登入錯誤:', error);
    res.status(500).json({ error: '伺服器錯誤' });
  }
};

// 確認船長的出勤登記記錄
const viewAttendance = async (req, res) => {
  const { worker_id, date } = req.body;

  try {
    if (!worker_id || !date) {
      return res.status(400).json({ error: '缺少必要參數，請提供 worker_id 和 date' });
    }

    // 查詢 Attendance 表
    const records = await Attendance.findAll({
      where: { worker_id, date },
      order: [['timeStart', 'ASC']],
    });

    if (records.length === 0) {
      return res.status(404).json({ error: '當天沒有找到相關記錄' });
    }

    res.json({ message: '記錄查詢成功', records });
  } catch (error) {
    console.error('查詢記錄失敗:', error);
    res.status(500).json({ error: '伺服器錯誤' });
  }
};

/*
// 簽到功能
const signin = async (req, res) => {
  const { worker_id, date, timeStart } = req.body;
  try {
    // 驗證登入的用戶是否與簽到的 worker_id 一致
    if (req.user.id !== worker_id) {
      return res.status(403).json({ error: '您無權為其他用戶簽到' });
    }

    if (!worker_id || !date || !timeStart) {
      return res.status(400).json({ error: '缺少必要參數' });
    }
    
    // 查找同一天未完成的簽到記錄
    const existingRecord = await Attendance.findOne({
      where: { worker_id, date, timeEnd: null },
    });

    // 如果存在未完成的記錄，刪除或更新
    if (existingRecord) {
      console.log(`已有未完成的簽到記錄，將刪除: ${existingRecord.id}`);
      await Attendance.destroy({ where: { id: existingRecord.id } });
    }


    const record = await Attendance.create({ worker_id, date, timeStart, status: 'working' });
    res.json({ message: '簽到成功', record });
  } catch (error) {
    console.error('簽到失敗:', error);
    res.status(500).json({ error: '伺服器錯誤，請檢查日誌' });
  }
};

// 簽退功能
const signout = async (req, res) => {
  const { worker_id, date, timeEnd } = req.body;
  try {
// 驗證登入的用戶是否與簽到的 worker_id 一致
    if (req.user.id !== worker_id) {
      return res.status(403).json({ error: '您無權為其他用戶簽到' });
    }

    if (!worker_id || !date || !timeEnd) {
      return res.status(400).json({ error: '缺少必要參數' });
    }

    // 更新資料
    const [affectedRows] = await Attendance.update(
      { timeEnd, status: 'resting' },
      { where: { worker_id, date, status: 'working' } }
    );

    // 如果有受影響的行，查詢最新資料
    if (affectedRows === 0) return res.status(404).json({ error: '無法找到記錄或已簽退' });

    const updatedRecord = await Attendance.findOne({
      where: { worker_id, date, status: 'resting', timeEnd }
    });

    res.json({ message: '簽退成功', record: updatedRecord });
  } catch (error) {
    console.error('簽退失敗:', error);
    res.status(500).json({ error: '伺服器錯誤，請檢查日誌' });
  }
};

module.exports = { login, signin, signout };
*/
module.exports = { login, viewAttendance };