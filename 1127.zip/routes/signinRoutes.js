const express = require('express');
const { login, viewAttendance } = require('../controllers/signinController');

const router = express.Router();

// 登入路由
router.post('/login', login);

// 簽到路由
router.post('/viewAttendance', viewAttendance);

module.exports = router;