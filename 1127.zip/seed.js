// 新增Login表的內容
const bcrypt = require('bcrypt');
const Login = require('./models/Login'); // 引入 Login 模型
const sequelize = require('./config/database'); // 引入資料庫連線

// 創建測試資料
const seedLoginData = async () => {
  try {
    // 連線到資料庫
    await sequelize.authenticate();
    console.log('資料庫連線成功');
    const hashedPassword = await bcrypt.hash('12345', 10);
    // 測試資料
    const testLogins = [
      {
        username: 'captain001',
        worker_id: null,
        role: 'captain',
        password: hashedPassword, // 使用加密後的密碼
        last_login: null,
        language: 'en-US',
        login_attempts: 0,
      },
      /*
      {
        username: 'worker001',
        worker_id: 1,
        role: 'worker',
        password: '54321',
        last_login: null,
        language: 'zh-TW',
        login_attempts: 0,
      },
      {
        username: 'worker002',
        worker_id: 2,
        role: 'worker',
        password: '12369',
        last_login: null,
        language: 'zh-TW',
        login_attempts: 0,
      },*/
    ];

    // 插入資料
    for (const login of testLogins) {
      await Login.create(login);
    }

    console.log('測試資料插入成功');
  } catch (error) {
    console.error('測試資料插入失敗:', error);
  } finally {
    // 關閉資料庫連線
    await sequelize.close();
  }
};

// 執行 seed 腳本
seedLoginData();
